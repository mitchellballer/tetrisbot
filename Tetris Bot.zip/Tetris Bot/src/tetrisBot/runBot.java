package tetrisBot;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import javax.imageio.*;

public class runBot {
		
	private Well well = new Well();
	
	
	public static void main(){
		try {
			click(690,560);
		} catch (AWTException e){
		}
		try {
			TimeUnit.SECONDS.sleep(9);
		} catch (InterruptedException e) {
		}
		screenShot();
		BufferedImage nextPieceImg = null;
		try{
			nextPieceImg = ImageIO.read(new File("ss.jpg"));
		} catch (IOException E) {
		}
		nextPieceImg = nextPieceImg.getSubimage(815,400,45,45);
		try {
			ImageIO.write(nextPieceImg, "jpg", new File("nextPieceImg.jpg"));
		} catch (IOException e) {
		}
		Piece nextPiece = toPiece(nextPieceImg);
		//System.out.println(nextPiece.shape);
		
		
	}
	
	public static Piece toPiece(BufferedImage img){
		BufferedImage var = null;
		try{
			var = ImageIO.read(new File("i.jpg"));
		} catch (IOException E) {
		}
		if (Piece.Compare(img,var)){
			return new Piece("i");
		}
		try{
			var = ImageIO.read(new File("l.jpg"));
		} catch (IOException E) {
		}
		if (Piece.Compare(img,var)){
			return new Piece("l");
		}
		try{
			var = ImageIO.read(new File("7.jpg"));
		} catch (IOException E) {
		}
		if (Piece.Compare(img,var)){
			return new Piece("7");
		}
		try{
			var = ImageIO.read(new File("square.jpg"));
		} catch (IOException E) {
		}
		if (Piece.Compare(img,var)){
			return new Piece("square");
		}
		try{
			var = ImageIO.read(new File("t.jpg"));
		} catch (IOException E) {
		}
		if (Piece.Compare(img,var)){
			return new Piece("t");
		}
		try{
			var = ImageIO.read(new File("s.jpg"));
		} catch (IOException E) {
		}
		if (Piece.Compare(img,var)){
			return new Piece("s");
		}
		try{
			var = ImageIO.read(new File("z.jpg"));
		} catch (IOException E) {
		}
		if (Piece.Compare(img,var)){
			return new Piece("z");
		}
		return null;
	}
	
	public static void click(int x, int y) throws AWTException{
	    Robot bot = new Robot();
	    bot.mouseMove(x, y);    
	    bot.mousePress(InputEvent.BUTTON1_MASK);
	    bot.mouseRelease(InputEvent.BUTTON1_MASK);
	}
	
	public static void screenShot() {
        try {
            Robot robot = new Robot();
            String format = "jpg";
            String fileName = "ss." + format;

            Rectangle screenSize = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage ss = robot.createScreenCapture(screenSize);
            ImageIO.write(ss, format, new File(fileName));
        } catch (AWTException | IOException ex) {
            System.err.println(ex);
        }
    }
	
	
	
}
