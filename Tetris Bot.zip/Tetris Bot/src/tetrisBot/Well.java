package tetrisBot;

public class Well {
	int[][] well;
	
	public Well(){
		well = new int[20][10];
	}

}
